Deltic Honk 0.14.01 by Michael Cowgill (ChurchOrganist)

This is a blatant hack of Gotlag's mod Honk which adds train horns to Factorio. 

It changes the horn sounds to the sounds used by the British Rail Class 55 Deltics in use on the East Coast main line between 1961 and 1981.

The samples are of real Deltic air horns.

This has been tested and appears to be working OK.

Hope you enjoy it :)

It is licensed under the MIT license, available in this package in the file  LICENSE.md.

Thank you to Gotlag for writing the original Honk mod.

For more information on this licence please visit: http://opensource.org/licenses/mit-license.html
